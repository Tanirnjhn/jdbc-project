package com.cg.springmvc.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.springmvc.bean.Customer;
import com.cg.springmvc.service.ICustomerService;

public class HomeController {
	@Autowired
	ICustomerService service;
     
     @RequestMapping("showRegistrationForm")
     public String showRegistrationForm(Model model) {
    	 Customer customer=new Customer();
    	 model.addAttribute("customer",customer);
     
    	 return "CustomerRegistration";
     }
     
     
  	@RequestMapping("registerUserAction")
    public String RegisterCustomerDetails(
    	@Valid @ModelAttribute("customer")Customer customer, 
  		BindingResult result,Model model) {
  		//code to process on customer details
  		if(result.hasErrors()) {
  			 return "CustomerRegistration";
  		}
  		customer=service.addCustomer(customer);
  		model.addAttribute("customer",customer);
  		return "Success";
  	}
}
